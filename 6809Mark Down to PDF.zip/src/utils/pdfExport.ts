import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { marked } from 'marked';

// Thai font support configuration
const THAI_FONTS = {
  sarabun: 'Sarabun',
  kanit: 'Kanit',
  prompt: 'Prompt'
};

// PDF export options
interface PDFExportOptions {
  filename?: string;
  format?: 'a4' | 'letter';
  orientation?: 'portrait' | 'landscape';
  margin?: number;
  quality?: number;
}

// Create styled container for PDF export
const markedOptions = {
  breaks: true,
  gfm: true,
  // ลบ mangle ที่ deprecated
};

// แก้ไข function เป็น async
async function createPDFContainer(content: string): Promise<HTMLElement> {
  const container = document.createElement('div');
  container.style.cssText = `
    font-family: 'Sarabun', 'TH Sarabun New', sans-serif;
    font-size: 14px;
    line-height: 1.6;
    color: #333;
    max-width: 210mm;
    margin: 0 auto;
    padding: 20mm;
  `;
  
  const result = marked(content, markedOptions);
  const htmlContent = typeof result === 'string' ? result : await result;
  container.innerHTML = htmlContent;
  
  return container;
}

// Export content as PDF
export async function exportToPDF(
  content: string,
  options: PDFExportOptions = {}
): Promise<void> {
  const {
    filename = 'document.pdf',
    format = 'a4',
    orientation = 'portrait',
    margin = 20,
    quality = 1.0
  } = options;
  
  try {
    // Create temporary container
    const container = createPDFContainer(content);
    document.body.appendChild(container);
    
    // Wait for fonts to load
    await document.fonts.ready;
    
    // Generate canvas from HTML
    const canvas = await html2canvas(container, {
      scale: quality,
      useCORS: true,
      allowTaint: true,
      backgroundColor: '#ffffff',
      logging: false,
      width: container.scrollWidth,
      height: container.scrollHeight
    });
    
    // Remove temporary container
    document.body.removeChild(container);
    
    // Create PDF
    const pdf = new jsPDF({
      orientation,
      unit: 'mm',
      format
    });
    
    // Calculate dimensions
    const pageWidth = pdf.internal.pageSize.getWidth();
    const pageHeight = pdf.internal.pageSize.getHeight();
    const imgWidth = pageWidth - (margin * 2);
    const imgHeight = (canvas.height * imgWidth) / canvas.width;
    
    // Add image to PDF
    const imgData = canvas.toDataURL('image/png');
    let heightLeft = imgHeight;
    let position = margin;
    
    // Add first page
    pdf.addImage(imgData, 'PNG', margin, position, imgWidth, imgHeight);
    heightLeft -= (pageHeight - margin * 2);
    
    // Add additional pages if needed
    while (heightLeft > 0) {
      position = heightLeft - imgHeight + margin;
      pdf.addPage();
      pdf.addImage(imgData, 'PNG', margin, position, imgWidth, imgHeight);
      heightLeft -= (pageHeight - margin * 2);
    }
    
    // Save PDF
    pdf.save(filename);
    
  } catch (error) {
    console.error('Error exporting PDF:', error);
    throw new Error('Failed to export PDF. Please try again.');
  }
}

// Export with Thai text optimization
export async function exportThaiToPDF(
  content: string,
  options: PDFExportOptions = {}
): Promise<void> {
  // Ensure Thai fonts are loaded
  const fontPromises = Object.values(THAI_FONTS).map(font => {
    return document.fonts.load(`16px ${font}`);
  });
  
  try {
    await Promise.all(fontPromises);
    await exportToPDF(content, options);
  } catch (error) {
    console.warn('Thai fonts not fully loaded, proceeding with fallback');
    await exportToPDF(content, options);
  }
}

// Quick export function
export function quickExportPDF(content: string, filename?: string): Promise<void> {
  return exportThaiToPDF(content, {
    filename: filename || `document-${new Date().toISOString().split('T')[0]}.pdf`,
    format: 'a4',
    orientation: 'portrait',
    quality: 1.2
  });
}