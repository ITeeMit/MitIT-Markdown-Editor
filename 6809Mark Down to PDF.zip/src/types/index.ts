export interface MarkdownDocument {
  id: string;
  title: string;
  content: string;
  createdAt: Date;
  updatedAt: Date;
  tags?: string[];
}

// เพิ่ม alias สำหรับ TMDDocument
export type TMDDocument = MarkdownDocument;

export interface AppSettings {
  theme: 'light' | 'dark' | 'system'; // เพิ่ม 'system' option
  editorFontSize: number;
  previewWidth: number;
  autoSave: boolean;
  autoSaveInterval: number;
}

export interface ExportOptions {
  format: 'md' | 'pdf' | 'xlsx' | 'html'; // เพิ่ม 'html' format
  filename: string;
  includeMetadata?: boolean;
  pageSize?: string; // เพิ่ม pageSize property
  margins?: {
    top?: number;
    left?: number;
    right?: number;
    bottom?: number;
  }; // เพิ่ม margins property
}

export interface ThemeContextType {
  theme: 'light' | 'dark';
  toggleTheme: () => void;
}

export interface EditorState {
  content: string;
  currentDocument: MarkdownDocument | null;
  isAutoSaving: boolean;
  lastSaved: Date | null;
}

// เพิ่ม missing interfaces
export interface DocumentStats {
  wordCount: number;
  characterCount: number;
  lineCount: number;
  readingTime: number;
}

export interface SearchResult {
  id: string;
  title: string;
  content: string;
  score: number;
}

export interface DocumentStore {
  documents: TMDDocument[];
  currentDocument: TMDDocument | null;
  searchResults: SearchResult[];
  isLoading: boolean;
  error: string | null;
}

export interface SettingsStore {
  settings: AppSettings;
  isLoading: boolean;
  error: string | null;
}

export type EditorTheme = 'light' | 'dark' | 'auto';

export interface UIStore {
  theme: EditorTheme;
  sidebarOpen: boolean;
  previewOpen: boolean;
  isFullscreen: boolean;
}