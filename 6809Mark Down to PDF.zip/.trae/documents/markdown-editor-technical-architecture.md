# MitIT Markdown Editor Web App - เอกสารสถาปัตยกรรมทางเทคนิค

## 1. Architecture Design

```mermaid
graph TD
    A[User Browser] --> B[React Frontend Application]
    B --> C[IndexedDB Storage]
    B --> D[Service Worker]
    B --> E[File System API]
    
    subgraph "Frontend Layer"
        B
        F[Vite Build Tool]
        G[TypeScript]
        H[TailwindCSS]
    end
    
    subgraph "Storage Layer"
        C
        I[Dexie.js]
    end
    
    subgraph "PWA Layer"
        D
        J[Web App Manifest]
        K[Cache Storage]
    end
    
    subgraph "Export Libraries"
        L[jsPDF]
        M[SheetJS/xlsx]
        N[Markdown Parser]
    end
```

## 2. Technology Description

* Frontend: React\@18 + TypeScript\@5 + Vite\@5 + TailwindCSS\@3

* Storage: IndexedDB + Dexie.js\@3

* PWA: Service Worker + Web App Manifest

* Export: jsPDF\@2 + SheetJS/xlsx\@0.18 + marked\@9

* Build Tool: Vite with PWA plugin

## 3. Route Definitions

| Route    | Purpose                                        |
| -------- | ---------------------------------------------- |
| /        | Main editor page with split-screen layout      |
| /offline | Offline fallback page when network unavailable |

## 4. API Definitions

### 4.1 Core Types

```typescript
interface MarkdownDocument {
  id: string;
  title: string;
  content: string;
  createdAt: Date;
  updatedAt: Date;
  tags?: string[];
}

interface AppSettings {
  theme: 'light' | 'dark';
  editorFontSize: number;
  previewWidth: number;
  autoSave: boolean;
  autoSaveInterval: number;
}

interface ExportOptions {
  format: 'md' | 'pdf' | 'xlsx';
  filename: string;
  includeMetadata?: boolean;
}
```

### 4.2 IndexedDB Schema

```typescript
// Dexie Database Schema
class MarkdownDB extends Dexie {
  documents!: Table<MarkdownDocument>;
  settings!: Table<AppSettings>;
  
  constructor() {
    super('MarkdownEditorDB');
    this.version(1).stores({
      documents: '++id, title, createdAt, updatedAt, tags',
      settings: '++id'
    });
  }
}
```

### 4.3 Service Worker Events

```typescript
// Service Worker API Events
interface ServiceWorkerEvents {
  install: () => Promise<void>;
  activate: () => Promise<void>;
  fetch: (event: FetchEvent) => Promise<Response>;
  sync: (event: SyncEvent) => Promise<void>;
}
```

## 5. Server Architecture Diagram

ไม่มี server-side architecture เนื่องจากเป็น client-side application ที่ทำงานแบบ standalone

```mermaid
graph TD
    A[Browser Runtime] --> B[React Application]
    B --> C[Component Layer]
    C --> D[Hook Layer]
    D --> E[Service Layer]
    E --> F[Storage Layer]
    
    subgraph "Client Architecture"
        B
        C
        D
        E
        F
    end
```

## 6. Data Model

### 6.1 Data Model Definition

```mermaid
erDiagram
    DOCUMENTS ||--o{ TAGS : has
    DOCUMENTS {
        string id PK
        string title
        text content
        datetime createdAt
        datetime updatedAt
    }
    TAGS {
        string id PK
        string name
        string documentId FK
    }
    SETTINGS {
        string id PK
        string theme
        number editorFontSize
        number previewWidth
        boolean autoSave
        number autoSaveInterval
    }
```

### 6.2 Data Definition Language

```javascript
// IndexedDB Schema Definition using Dexie.js
const db = new Dexie('MarkdownEditorDB');

// Version 1 Schema
db.version(1).stores({
  documents: '++id, title, createdAt, updatedAt, *tags',
  settings: '++id, theme, editorFontSize, previewWidth, autoSave'
});

// Initial Settings Data
db.settings.add({
  id: 'default',
  theme: 'light',
  editorFontSize: 16,
  previewWidth: 50,
  autoSave: true,
  autoSaveInterval: 5000
});

// Sample Document Data
db.documents.add({
  id: 'welcome-doc',
  title: 'Welcome to Markdown Editor',
  content: '# Welcome\n\nStart writing your markdown here...',
  createdAt: new Date(),
  updatedAt: new Date(),
  tags: ['welcome', 'tutorial']
});

// Indexes for Performance
db.documents.createIndex('title', 'title');
db.documents.createIndex('createdAt', 'createdAt');
db.documents.createIndex('updatedAt', 'updatedAt');
```

### 6.3 Component Architecture

```typescript
// Main Component Structure
interface ComponentHierarchy {
  App: {
    Header: {
      Toolbar: string[];
      ThemeToggle: boolean;
    };
    MainContent: {
      EditorPanel: {
        MarkdownEditor: string;
        StatusBar: object;
      };
      PreviewPanel: {
        HTMLPreview: string;
        ScrollSync: boolean;
      };
    };
    Modals: {
      FileManager: object;
      ExportDialog: object;
      SettingsDialog: object;
    };
  };
}
```

### 6.4 PWA Configuration

```json
{
  "name": "MitIT Markdown Editor",
  "short_name": "MDEditor",
  "description": "Offline MitIT Markdown Editor with Live Preview",
  "start_url": "/",
  "display": "standalone",
  "background_color": "#ffffff",
  "theme_color": "#3B82F6",
  "icons": [
    {
      "src": "/icons/icon-192.png",
      "sizes": "192x192",
      "type": "image/png"
    },
    {
      "src": "/icons/icon-512.png",
      "sizes": "512x512",
      "type": "image/png"
    }
  ],
  "categories": ["productivity", "utilities"],
  "screenshots": [
    {
      "src": "/screenshots/desktop.png",
      "sizes": "1280x720",
      "type": "image/png",
      "form_factor": "wide"
    }
  ]
}
```

