# MitIT Markdown Editor Web App - เอกสารความต้องการผลิตภัณฑ์ (Updated)

## 1. Product Overview
แอปพลิเคชัน **MitIT Markdown Editor** ที่ทำงานบนเว็บเบราว์เซอร์ พร้อมความสามารถในการแก้ไข Markdown แบบ real-time และดูตัวอย่าง HTML ในเวลาเดียวกัน รองรับการทำงานแบบ offline และสามารถติดตั้งเป็น PWA ได้

แอปพลิเคชันนี้ช่วยให้ผู้ใช้สามารถเขียนและแก้ไขเอกสาร Markdown ได้อย่างสะดวก พร้อมฟีเจอร์การ export เป็นไฟล์หลายรูปแบบ และจัดเก็บข้อมูลในเครื่องผ่าน IndexedDB

**สถานะปัจจุบัน**: โปรเจคได้รับการพัฒนาเสร็จสมบูรณ์แล้ว ใช้เทคโนโลยี React + TypeScript + Vite + TailwindCSS พร้อม PWA support

## 2. Technical Stack (Implemented)

### 2.1 Frontend Framework
- **React 18.3.1** with TypeScript
- **Vite 6.3.5** สำหรับ build tool
- **TailwindCSS 3.4.17** สำหรับ styling
- **Zustand 5.0.3** สำหรับ state management

### 2.2 Core Dependencies
- **marked 14.1.2** - Markdown to HTML conversion
- **dexie 4.0.8** - IndexedDB wrapper
- **jspdf 2.5.2** - PDF export functionality
- **xlsx 0.18.5** - Excel export functionality
- **lucide-react 0.511.0** - Icon library
- **html2canvas 1.4.1** - Screenshot functionality

### 2.3 PWA Features
- **vite-plugin-pwa 0.21.1** - PWA configuration
- **workbox-window 7.1.0** - Service worker management
- Offline support และ app installation

## 3. Core Features (Implemented)

### 3.1 Main Components
1. **OMarkdownEditor** - Editor panel with auto-save
2. **OPreviewPanel** - Real-time HTML preview
3. **OToolbar** - Formatting tools และ export functions
4. **OFileManager** - Document management sidebar
5. **OThemeToggle** - Dark/Light theme switcher

### 3.2 Feature Details

| Component | Features | Implementation Status |
|-----------|----------|----------------------|
| **Editor Panel** | Textarea with auto-save, keyboard shortcuts, font customization | ✅ Completed |
| **Preview Panel** | Real-time markdown rendering, custom CSS styling, responsive | ✅ Completed |
| **Toolbar** | Import/Export (.md, PDF, Excel), formatting buttons, print function | ✅ Completed |
| **File Manager** | Document CRUD, search functionality, tags support | ✅ Completed |
| **Theme System** | Light/Dark mode toggle, system theme detection | ✅ Completed |
| **Status Bar** | Document info display, MitIT watermark | ✅ Completed |
| **PWA Features** | Offline support, installable app, service worker | ✅ Completed |

### 3.3 Database Schema (IndexedDB)
```typescript
// Documents table
interface MarkdownDocument {
  id: string;
  title: string;
  content: string;
  createdAt: Date;
  updatedAt: Date;
  tags: string[];
}

// Settings table
interface AppSettings {
  theme: 'light' | 'dark' | 'system';
  fontSize: number;
  fontFamily: string;
  autoSave: boolean;
  autoSaveInterval: number;
}
```

## 4. User Interface Design (Current Implementation)

### 4.1 Layout Structure
┌─────────────────────────────────────────────────────────┐
│                    Toolbar                              │
├─────────────┬───────────────────┬───────────────────────┤
│             │                   │                       │
│ File        │   Markdown        │    HTML Preview       │
│ Manager     │   Editor          │    Panel              │
│ Sidebar     │                   │                       │
│             │                   │                       │
├─────────────┴───────────────────┴───────────────────────┤
│          Status Bar with MitIT Watermark                │
└─────────────────────────────────────────────────────────┘

### 4.2 Design System
- **Primary Colors**: Blue (#3B82F6), Gray (#6B7280)
- **Theme Support**: Light และ Dark mode
- **Typography**: Inter font family, responsive font sizes
- **Icons**: Lucide React icons
- **Responsive**: Desktop-first with mobile support

### 4.3 Key UI Features
- **Split-screen layout** สำหรับ desktop
- **Collapsible sidebar** สำหรับ file management
- **Responsive toolbar** พร้อม formatting tools
- **Status bar** แสดงข้อมูลเอกสารและ MitIT watermark
- **Modal dialogs** สำหรับ file operations

## 5. Export Capabilities

### 5.1 Supported Formats
1. **Markdown (.md)** - Native format export
2. **PDF** - Using jsPDF with custom styling
3. **Excel (.xlsx)** - Document metadata และ content
4. **Print** - Browser print with custom CSS

### 5.2 Export Features
- **Quick export** buttons ใน toolbar
- **Custom PDF styling** พร้อม page formatting
- **Batch export** capabilities
- **Print preview** functionality

## 6. Performance & Optimization

### 6.1 Auto-save System
- **Debounced auto-save** ทุก 2 วินาทีหลังจากหยุดพิมพ์
- **IndexedDB storage** สำหรับ offline persistence
- **Real-time content sync** ระหว่าง editor และ preview

### 6.2 PWA Optimization
- **Service worker caching** สำหรับ static assets
- **Offline functionality** พร้อม fallback UI
- **App installation** prompt
- **Background sync** capabilities

## 7. Responsive Design

### 7.1 Breakpoints
- **Desktop** (lg+): Split-screen layout
- **Tablet** (md): Collapsible sidebar
- **Mobile** (sm): Tab-based navigation

### 7.2 Mobile Features
- **Touch-friendly** interface
- **Swipe gestures** สำหรับ navigation
- **Optimized keyboard** handling
- **Responsive typography** scaling

## 8. Security & Data Management

### 8.1 Data Storage
- **Client-side only** - ไม่มีการส่งข้อมูลไปยัง server
- **IndexedDB encryption** สำหรับ sensitive data
- **Local storage** สำหรับ user preferences

### 8.2 Privacy
- **No tracking** หรือ analytics
- **Offline-first** approach
- **User data ownership** - ข้อมูลอยู่ในเครื่องผู้ใช้เท่านั้น

## 9. Future Enhancements

### 9.1 Planned Features
- [ ] **Collaborative editing** support
- [ ] **Cloud sync** integration
- [ ] **Plugin system** สำหรับ extensions
- [ ] **Advanced export** options (Word, HTML)
- [ ] **Version control** integration

### 9.2 Performance Improvements
- [ ] **Virtual scrolling** สำหรับ large documents
- [ ] **Web Workers** สำหรับ heavy processing
- [ ] **Code splitting** optimization

## 10. Deployment & Distribution

### 10.1 Build Configuration
- **Vite production build** พร้อม optimization
- **PWA manifest** configuration
- **Service worker** registration
- **Static asset optimization**

### 10.2 Hosting Options
- **Static hosting** (Netlify, Vercel, GitHub Pages)
- **CDN distribution** สำหรับ global access
- **PWA installation** จาก web browser

---

**Document Version**: 2.0  
**Last Updated**: 2025-09-09  
**Status**: ✅ Fully Implemented  
**Next Review**: Q3 2025